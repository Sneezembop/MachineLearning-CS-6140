Miles Benjamin
CS 6140
Homework 1

Contents:
	Assignment 1.pdf - a copy of the written report
	Assignment 1.ipynb - the jupyter notebook with the python code
	Assignment+1.py	- the downloaded python file from jupyter notebook (I have no confidence in this file.)
	Python_Printout.pdf - the printout of the jupyter notebook file
	HW1_Data - the folder containting the data, do not move!

To execute the code for this assignment simply unpack the zip then open Assignment 1.ipynb in Jupyter Notebooks.  This code uses Python 3.6
