Miles Benjamin
CS 6140
Homework 3

Contents:
	Assignment 3.pdf - a copy of the written report
	Assignment 3.ipynb - the jupyter notebook with the python code for questions 4 - 7
	Python_Printout.pdf - the printout of the jupyter notebook file
	HW3_Data - the folder containting the data, do not move!

To execute the code for this assignment simply unpack the zip then open Assignment 3.ipynb in Jupyter Notebooks.  This code uses Python 3.6

I have included .py files which are ports of the jupyter notebook files.  
I haven't run them and I don't have a huge amount of confidence in them.  
I highly recommend using jupyter notebook instead.
