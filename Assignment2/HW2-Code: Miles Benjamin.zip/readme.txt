Miles Benjamin
CS 6140
Homework 2

Contents:
	Assignment 2.pdf - a copy of the written report
	Assignment 2-7.ipynb - the jupyter notebook with the python code for question 7
	Assignment 2-8.ipynb - the jupyter notebook with the python code for question 8
	Python_Printout.pdf - the printout of the jupyter notebook file
	HW2_Data - the folder containting the data, do not move!

To execute the code for this assignment simply unpack the zip then open Assignment 2-7.ipynb and Assignment 2-8.ipynb in Jupyter Notebooks.  This code uses Python 3.6

I have included .py files which are ports of the jupyter notebook files.  
I haven't run them and I don't have a huge amount of confidence in them.  
I highly recommend using jupyter notebook instead.
